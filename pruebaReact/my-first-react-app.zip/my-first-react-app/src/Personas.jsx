const personas = [
    { 
        name: 'Daniel',
        age: 29,
        email: 'dluqueru@gmail.com'
    },{
        name: 'Cristina',
        age: 31,
        email: 'cristina@gmail.com'
    },{
        name: 'Paco',
        age: 54,
        email: 'paco@gmail.com'
    }
]

export default personas